from tkinter import *
from tkinter import scrolledtext
import time
from datetime import datetime as dt
root = Tk()
root.geometry('500x300')
root.resizable(0,0)
root.title("Social Media Blocker(test)")
Label(root, text ='Social Media Blocker' , font ='arial 20 bold').pack()


host_path = "C:\Windows\System32\drivers\etc\hosts"
redirect = "127.0.0.1"
websites_lists = [ "facebook.com" , "www.facebook.com" , "www.reddit.com" ,"reddit.com" , "instagram.com" , "www.instagram.com" , "twitter.com" , "www.twitter.com"]
text = Label(root,text= "Social Media Sites will be blocked when you hit 'Block' in working hours" , font="arial 9", fg="black").place(x=0,y=45)
text2 = Label(text= "sites include Facebook , Reddit , Instagram and Twitter ", font="arial 9", fg="black").place(x=0,y=67)
Label(root,text="WORKING HOURS STARTS FROM 8:00AM TO 04:00PM",font="arial 9", fg="red").place(x=0,y=89)
def blocker():
    while True :
        if dt(dt.now().year , dt.now().month , dt.now().day , 8) < dt.now() <  dt(dt.now().year , dt.now().month , dt.now().day , 16):
            with open(host_path , "r+") as file:
                content = file.read()
                for website in websites_lists:
                    if website in content:
                        pass
                    else:
                        file.write(redirect+ " "+ website + "\n")

            Label(root, text = 'Blocked' , font = 'arial 12 bold' ,fg="red" , bg="green").place(x=230,y=220)
            break
        else:
            with open(host_path, "r+") as file:
                content = file.readlines()
                file.seek(0)

                for line in content:
                    if not any(website in line for website in websites_lists):
                        file.write(line)
                file.truncate()
            
            Label(root, text = "Can't block" , font = 'arial 12 bold', fg="light cyan" , bg="green").place(x=230,y=220)
            
            break
block = Button(root, text = 'Block',font = 'arial 12 bold',pady = 5,command = blocker ,width = 6, bg = 'royal blue1', activebackground = 'sky blue')
block.place(x = 230, y = 170)
root.mainloop()