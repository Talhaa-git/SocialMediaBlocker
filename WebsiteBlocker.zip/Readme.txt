# Social Media Blocker

For more Productivity in corporates and educational institutes. 

## Installation

This application is made in Python,so python is required to run this.

Python Library TKinker should also be required.
see documentation here [docs](https://docs.python.org/3/library/tk.html)


```bash
pip install TKinker
```


## Contributing
This is Currently in Testing.

Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.
